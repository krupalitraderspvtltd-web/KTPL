"use client";

import Image from "next/image";
import { ArrowRight } from "lucide-react";
import { useTranslations } from "next-intl";

import { Link } from "@/i18n/routing";

export default function AboutPage() {
  const t = useTranslations("AboutPage");

  return (
    <main className="relative w-full overflow-hidden bg-[#071b34]">

      {/* =====================================================
          HERO
          IMPORTANT:
          No top padding / margin here.
          Hero starts immediately under Navbar.
      ===================================================== */}

      <section
        className="
          relative
          m-0
          min-h-[calc(100vh-88px)]
          w-full
          overflow-hidden
          p-0
        "
      >

        {/* HERO IMAGE */}

        <Image
          src="/Krupali-Traders-Logo.gif"
          alt="Krupali Traders Private Limited"
          fill
          priority
          className="hidden"
        />

        <Image
          src="/assets/about-hero.jpg"
          alt="Krupali Traders international import and export operations"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center"
        />

        {/* Image overlay */}

        <div className="absolute inset-0 bg-black/25" />

        <div className="absolute inset-0 bg-gradient-to-t from-[#061426]/80 via-transparent to-black/10" />

        {/* =================================================
            HERO CONTENT
        ================================================= */}

        <div className="relative z-10 flex min-h-[calc(100vh-88px)] items-end justify-center px-5 pb-12 pt-28 text-center sm:px-8 sm:pb-16 lg:pb-20">

          <div className="mx-auto max-w-4xl">

            {/* Tag */}

            <div className="mb-4 text-xs font-bold uppercase tracking-[0.25em] text-[#d8b45b] sm:text-sm">
              {t("heroTag")}
            </div>

            {/* Description */}

            <p className="mx-auto max-w-3xl text-base leading-7 text-white/90 sm:text-lg sm:leading-8">
              {t("heroDescription")}
            </p>

            {/* Buttons */}

            <div className="mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row">

              <Link
                href="/about"
                className="
                  inline-flex
                  items-center
                  gap-2
                  rounded-full
                  border
                  border-white/50
                  bg-black/20
                  px-6
                  py-3
                  text-sm
                  font-semibold
                  text-white
                  backdrop-blur-sm
                  transition
                  duration-300
                  hover:-translate-y-1
                  hover:bg-white/10
                "
              >
                {t("learnMore")}
                <ArrowRight size={17} />
              </Link>

              <Link
                href="/request-quote"
                className="
                  inline-flex
                  items-center
                  gap-2
                  rounded-full
                  bg-[#d8b45b]
                  px-6
                  py-3
                  text-sm
                  font-semibold
                  text-[#071b34]
                  shadow-lg
                  transition
                  duration-300
                  hover:-translate-y-1
                  hover:bg-[#e7c873]
                "
              >
                {t("getQuote")}
                <ArrowRight size={17} />
              </Link>

            </div>

          </div>

        </div>

      </section>

      {/* =====================================================
          ABOUT CONTENT
      ===================================================== */}

      <section className="relative bg-[#0b2749] px-5 py-20 sm:px-8 lg:px-10">

        <div className="mx-auto max-w-7xl">

          <div className="grid gap-12 lg:grid-cols-2 lg:items-center">

            <div>

              <div className="text-sm font-bold uppercase tracking-[0.2em] text-[#c9a24d]">
                {t("aboutTag")}
              </div>

              <h2 className="mt-4 text-4xl font-bold leading-tight tracking-tight text-white sm:text-5xl">
                {t("aboutTitle1")}

                <span className="block text-[#68b0ff]">
                  {t("aboutTitle2")}
                </span>
              </h2>

              <p className="mt-6 max-w-xl text-base leading-8 text-white/65 sm:text-lg">
                {t("aboutDesc")}
              </p>

              <Link
                href="/contact"
                className="
                  mt-7
                  inline-flex
                  items-center
                  gap-2
                  rounded-full
                  bg-[#1455a0]
                  px-6
                  py-3
                  font-semibold
                  text-white
                  transition
                  hover:-translate-y-1
                  hover:bg-[#1d69c4]
                "
              >
                {t("contactBtn")}
                <ArrowRight size={17} />
              </Link>

            </div>

            {/* RIGHT SIDE */}

            <div className="grid gap-4 sm:grid-cols-2">

              <div className="rounded-3xl border border-white/10 bg-[#071b34]/70 p-7 backdrop-blur-sm">

                <div className="text-3xl font-bold text-[#68b0ff]">
                  {t("globalReach")}
                </div>

                <p className="mt-3 text-sm leading-7 text-white/55">
                  {t("globalReachDesc")}
                </p>

              </div>

              <div className="rounded-3xl border border-white/10 bg-[#071b34]/70 p-7 backdrop-blur-sm">

                <div className="text-3xl font-bold text-[#68b0ff]">
                  {t("trustedTrade")}
                </div>

                <p className="mt-3 text-sm leading-7 text-white/55">
                  {t("trustedTradeDesc")}
                </p>

              </div>

            </div>

          </div>

        </div>

      </section>

    </main>
  );
}