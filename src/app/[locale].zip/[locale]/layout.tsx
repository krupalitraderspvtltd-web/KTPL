import type { Metadata } from "next";
import { NextIntlClientProvider } from "next-intl";
import { getMessages } from "next-intl/server";

import { ThemeProvider } from "@/components/layout/ThemeProvider";
import ClientLayoutWrapper from "@/components/layout/ClientLayoutWrapper";
import OrganizationJsonLd from "@/components/seo/OrganizationJsonLd";

import "../globals.css";

const SITE_URL = "https://www.krupalitraderspvtltd.com";
const SITE_NAME = "Krupali Traders Private Limited";

const DEFAULT_TITLE =
  "Krupali Traders Private Limited | Global Import & Export Company";

const DEFAULT_DESCRIPTION =
  "Krupali Traders Private Limited is an India-based import and export company supplying Indian spices, fresh fruits, vegetables, herbs, dry fruits, nuts, seafood and other trade products to global buyers.";

const KEYWORDS = [
  "Krupali Traders",
  "Krupali Traders Private Limited",
  "Krupali Traders India",
  "Krupali Traders Gujarat",
  "Krupali Traders exporter",
  "Krupali Traders import export",
  "Indian spices exporter",
  "Indian spices supplier",
  "fresh fruits exporter India",
  "fresh vegetables exporter India",
  "Indian herbs exporter",
  "dry fruits exporter India",
  "nuts exporter India",
  "seafood exporter India",
  "fish exporter India",
  "dry fish exporter India",
  "import export company India",
  "Gujarat export company",
];

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: DEFAULT_TITLE,
    template: `%s | ${SITE_NAME}`,
  },
  description: DEFAULT_DESCRIPTION,
  keywords: KEYWORDS,
  applicationName: SITE_NAME,
  authors: [{ name: SITE_NAME, url: SITE_URL }],
  creator: SITE_NAME,
  publisher: SITE_NAME,
  alternates: {
    canonical: "/en",
    languages: {
      en: "/en",
      gu: "/gu",
      hi: "/hi",
      ar: "/ar",
    },
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
      "max-video-preview": -1,
    },
  },
  openGraph: {
    type: "website",
    locale: "en_IN",
    url: `${SITE_URL}/en`,
    siteName: SITE_NAME,
    title: DEFAULT_TITLE,
    description: DEFAULT_DESCRIPTION,
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: `${SITE_NAME} - Global Import & Export Company`,
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: DEFAULT_TITLE,
    description: DEFAULT_DESCRIPTION,
    images: ["/og-image.jpg"],
  },
  category: "business",
};

type LocaleLayoutProps = {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
};

export default async function LocaleLayout({
  children,
  params,
}: LocaleLayoutProps) {
  const { locale } = await params;
  const messages = await getMessages();

  const direction = locale === "ar" ? "rtl" : "ltr";

  return (
    <html
      lang={locale}
      dir={direction}
      suppressHydrationWarning
    >
      <body suppressHydrationWarning>
        <NextIntlClientProvider messages={messages} locale={locale}>
          <ThemeProvider>
            <OrganizationJsonLd locale={locale} />

            <ClientLayoutWrapper>
              {children}
            </ClientLayoutWrapper>
          </ThemeProvider>
        </NextIntlClientProvider>
      </body>
    </html>
  );
}
